# Detail View 
### Tutorials to learn to build this project
*We will create a view that is going to be our Detail View
which will display detail information to each pokemon in our row ✨*

📖 **Article: [Detail View](https://medium.com/@martinlasek/swiftui-detail-view-44772246fa2a)**
<br />
🎥 **Video: [Detail View](https://youtu.be/PHd8MDgxHrA)**

![Image of Detail View](screenshot.gif)

